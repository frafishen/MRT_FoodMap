// Home.vue文件的内容
<template>
  <div>
    <p>主页</p>
  </div>
</template>
